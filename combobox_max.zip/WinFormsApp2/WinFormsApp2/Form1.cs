namespace WinFormsApp2
{
    public partial class Form1 : Form
    {
        public int  maximum = 50;
        public Form1()
        {
            InitializeComponent();
            
        }

        private void Form1_Load(object sender, EventArgs e)
        {

        }

        private void comboBox1_SelectedIndexChanged(object sender, EventArgs e)
        {


        }

        private void button1_Click(object sender, EventArgs e)
        {
            
                if (Int32.Parse(comboBox1.Text) > maximum)
                {
                    MessageBox.Show("Nincs ennyi k�rd�s, a maximum 50");
                    
                }

            
           
        }
    }
}
