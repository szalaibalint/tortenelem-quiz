﻿namespace WinFormsApp2
{
    partial class singlequestion
    {
        /// <summary> 
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary> 
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Component Designer generated code

        /// <summary> 
        /// Required method for Designer support - do not modify 
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            label1 = new Label();
            radioButton1 = new RadioButton();
            radioButton2 = new RadioButton();
            radioButton3 = new RadioButton();
            radioButton4 = new RadioButton();
            SuspendLayout();
            // 
            // label1
            // 
            label1.Font = new Font("Javanese Text", 18F, FontStyle.Bold, GraphicsUnit.Point, 0);
            label1.Location = new Point(103, 51);
            label1.Name = "label1";
            label1.Size = new Size(376, 47);
            label1.TabIndex = 0;
            label1.Text = "Random cim minta ki votl bla?";
            // 
            // radioButton1
            // 
            radioButton1.Appearance = Appearance.Button;
            radioButton1.AutoSize = true;
            radioButton1.BackColor = Color.Tan;
            radioButton1.FlatAppearance.BorderSize = 0;
            radioButton1.FlatStyle = FlatStyle.Flat;
            radioButton1.Font = new Font("Javanese Text", 11.25F, FontStyle.Bold);
            radioButton1.Location = new Point(103, 149);
            radioButton1.Name = "radioButton1";
            radioButton1.Size = new Size(120, 44);
            radioButton1.TabIndex = 1;
            radioButton1.TabStop = true;
            radioButton1.Text = "radioButton1";
            radioButton1.UseVisualStyleBackColor = false;
            // 
            // radioButton2
            // 
            radioButton2.Appearance = Appearance.Button;
            radioButton2.AutoSize = true;
            radioButton2.BackColor = Color.Tan;
            radioButton2.FlatAppearance.BorderSize = 0;
            radioButton2.FlatStyle = FlatStyle.Flat;
            radioButton2.Font = new Font("Javanese Text", 11.25F, FontStyle.Bold);
            radioButton2.Location = new Point(103, 229);
            radioButton2.Name = "radioButton2";
            radioButton2.Size = new Size(122, 44);
            radioButton2.TabIndex = 2;
            radioButton2.TabStop = true;
            radioButton2.Text = "radioButton2";
            radioButton2.UseVisualStyleBackColor = false;
            // 
            // radioButton3
            // 
            radioButton3.Appearance = Appearance.Button;
            radioButton3.AutoSize = true;
            radioButton3.BackColor = Color.Tan;
            radioButton3.FlatAppearance.BorderSize = 0;
            radioButton3.FlatStyle = FlatStyle.Flat;
            radioButton3.Font = new Font("Javanese Text", 11.25F, FontStyle.Bold);
            radioButton3.Location = new Point(349, 149);
            radioButton3.Name = "radioButton3";
            radioButton3.Size = new Size(122, 44);
            radioButton3.TabIndex = 3;
            radioButton3.TabStop = true;
            radioButton3.Text = "radioButton3";
            radioButton3.UseVisualStyleBackColor = false;
            // 
            // radioButton4
            // 
            radioButton4.Appearance = Appearance.Button;
            radioButton4.AutoSize = true;
            radioButton4.BackColor = Color.Tan;
            radioButton4.FlatAppearance.BorderSize = 0;
            radioButton4.FlatStyle = FlatStyle.Flat;
            radioButton4.Font = new Font("Javanese Text", 11.25F, FontStyle.Bold);
            radioButton4.Location = new Point(349, 229);
            radioButton4.Name = "radioButton4";
            radioButton4.Size = new Size(123, 44);
            radioButton4.TabIndex = 4;
            radioButton4.TabStop = true;
            radioButton4.Text = "radioButton4";
            radioButton4.UseVisualStyleBackColor = false;
            // 
            // singlequestion
            // 
            AutoScaleDimensions = new SizeF(7F, 15F);
            AutoScaleMode = AutoScaleMode.Font;
            BackColor = Color.PapayaWhip;
            Controls.Add(radioButton4);
            Controls.Add(radioButton3);
            Controls.Add(radioButton2);
            Controls.Add(radioButton1);
            Controls.Add(label1);
            Name = "singlequestion";
            Size = new Size(570, 350);
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion

        private Label label1;
        private RadioButton radioButton1;
        private RadioButton radioButton2;
        private RadioButton radioButton3;
        private RadioButton radioButton4;
    }
}
