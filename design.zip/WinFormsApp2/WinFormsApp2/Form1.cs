namespace WinFormsApp2
{
    public partial class Form1 : Form
    {
        public int maximum = 50;
        public Form1()
        {
            InitializeComponent();
            comboBox1.Text = "1";

        }

        private void Form1_Load(object sender, EventArgs e)
        {

        }

        private void comboBox1_SelectedIndexChanged(object sender, EventArgs e)
        {


        }

        private void button1_Click(object sender, EventArgs e)
        {

            if (Int32.Parse(comboBox1.Text) > maximum)
            {
                MessageBox.Show("Nincs ennyi k�rd�s, a maximum 50");

            }





        }

        private void panel1_Paint(object sender, PaintEventArgs e)
        {

        }
    }
}
